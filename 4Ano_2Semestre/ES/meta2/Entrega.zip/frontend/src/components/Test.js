import React, { Component } from "react";
import './Test.css';

export default class Test extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <p  className = "red">Hellooooo</p>
    );
  }
}